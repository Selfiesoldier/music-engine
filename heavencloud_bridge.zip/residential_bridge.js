import http from 'http';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Detect yt-dlp binary (local Linux binary, local Windows exe, or system path)
const YTDLP_PATH = fs.existsSync(path.join(__dirname, 'yt-dlp'))
  ? path.join(__dirname, 'yt-dlp')
  : (process.platform === 'win32' && fs.existsSync(path.join(__dirname, 'yt-dlp.exe'))
    ? path.join(__dirname, 'yt-dlp.exe')
    : 'yt-dlp');

// Automatically ensure executable permission on Linux
if (process.platform !== 'win32' && fs.existsSync(path.join(__dirname, 'yt-dlp'))) {
  try {
    fs.chmodSync(path.join(__dirname, 'yt-dlp'), 0o755);
    console.log('✅ Set executable permissions (0755) on ./yt-dlp');
  } catch (e) {
    console.warn('⚠️ Could not chmod ./yt-dlp:', e.message);
  }
}

const COOKIES_PATH = path.join(__dirname, 'cookies.txt');
const CACHE_DIR = path.join(__dirname, 'bridge_cache');

// Support Pterodactyl SERVER_PORT, standard PORT, or explicit 30191
const PORT = process.env.SERVER_PORT || process.env.PORT || 30191;

if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

function getCacheKey(targetUrl) {
  return crypto.createHash('md5').update(targetUrl).digest('hex');
}

const server = http.createServer(async (req, res) => {
  const reqUrl = new URL(req.url, `http://${req.headers.host}`);
  
  if (reqUrl.pathname === '/' || reqUrl.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({
      status: 'ok',
      service: 'heavencloud_audio_bridge',
      port: PORT,
      ytdlp: YTDLP_PATH,
      hasCookies: fs.existsSync(COOKIES_PATH),
      timestamp: Date.now()
    }));
  }

  // Diagnostic endpoint to check yt-dlp binary execution
  if (reqUrl.pathname === '/test') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    try {
      const p = spawn(YTDLP_PATH, ['--version']);
      let stdout = '', stderr = '';
      p.stdout.on('data', d => stdout += d.toString());
      p.stderr.on('data', d => stderr += d.toString());
      p.on('error', err => {
        res.end(JSON.stringify({ success: false, error: err.message, ytdlp: YTDLP_PATH }));
      });
      p.on('close', code => {
        res.end(JSON.stringify({
          success: code === 0,
          code,
          version: stdout.trim(),
          stderr: stderr.trim(),
          ytdlp: YTDLP_PATH
        }));
      });
    } catch (e) {
      res.end(JSON.stringify({ success: false, error: e.message }));
    }
    return;
  }

  if (reqUrl.pathname === '/stream') {
    const targetUrl = reqUrl.searchParams.get('url');
    if (!targetUrl) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Missing ?url= query parameter' }));
    }

    const key = getCacheKey(targetUrl);
    const cachedFile = path.join(CACHE_DIR, `${key}.m4a`);

    console.log(`[Bridge] 📥 Request for: ${targetUrl}`);

    // If cached and valid, stream immediately
    if (fs.existsSync(cachedFile)) {
      const stats = fs.statSync(cachedFile);
      if (stats.size > 50000) {
        console.log(`[Bridge] ⚡ Serving cached file (${(stats.size / 1024 / 1024).toFixed(2)} MB)...`);
        res.writeHead(200, {
          'Content-Type': 'audio/mp4',
          'Content-Length': stats.size,
          'Cache-Control': 'public, max-age=86400',
          'X-Bridge-Source': 'heavencloud-cache'
        });
        return fs.createReadStream(cachedFile).pipe(res);
      }
    }

    // Download complete audio file using the server's network
    const tempFile = path.join(CACHE_DIR, `${key}.temp.m4a`);
    try { if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile); } catch (_) {}

    const args = [
      '-f', 'ba[ext=m4a]/ba[ext=webm]/ba',
      '-o', tempFile,
      '--no-playlist',
      '--no-warnings',
      '--extractor-args', 'youtube:player_client=visionos,android'
    ];

    if (fs.existsSync(COOKIES_PATH)) {
      args.push('--cookies', COOKIES_PATH);
    }

    args.push(targetUrl);

    console.log(`[Bridge] 🚀 Downloading track with yt-dlp...`);
    let ytProcess;
    try {
      ytProcess = spawn(YTDLP_PATH, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (spawnErr) {
      console.error(`[Bridge] ❌ Failed to spawn yt-dlp: ${spawnErr.message}`);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify({ error: 'Failed to spawn yt-dlp', details: spawnErr.message }));
    }

    let errBuffer = '';
    ytProcess.stderr.on('data', (d) => { errBuffer += d.toString(); });

    ytProcess.on('error', (err) => {
      console.error(`[Bridge] ❌ Process error: ${err.message}`);
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Process execution error', details: err.message }));
      }
    });

    ytProcess.on('close', (code) => {
      if (code !== 0 || !fs.existsSync(tempFile)) {
        console.error(`[Bridge] ❌ Download failed (code ${code}): ${errBuffer.slice(0, 250)}`);
        if (!res.headersSent) {
          res.writeHead(502, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Download failed', code, details: errBuffer }));
        }
        return;
      }

      // Rename temp file to cached file
      try {
        if (fs.existsSync(cachedFile)) fs.unlinkSync(cachedFile);
        fs.renameSync(tempFile, cachedFile);
      } catch (_) {}

      const fileToStream = fs.existsSync(cachedFile) ? cachedFile : tempFile;
      const stats = fs.statSync(fileToStream);

      console.log(`[Bridge] ✅ Success! Streaming ${(stats.size / 1024 / 1024).toFixed(2)} MB to bot...`);
      res.writeHead(200, {
        'Content-Type': 'audio/mp4',
        'Content-Length': stats.size,
        'Cache-Control': 'public, max-age=86400',
        'X-Bridge-Source': 'heavencloud-direct'
      });

      fs.createReadStream(fileToStream).pipe(res);
    });

    req.on('close', () => {
      if (ytProcess && !ytProcess.killed) {
        try { ytProcess.kill(); } catch (_) {}
      }
    });

    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Endpoint not found' }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 HeavenCloud Audio Bridge running on port ${PORT}`);
  console.log(`📍 Using yt-dlp: ${YTDLP_PATH}`);
  if (fs.existsSync(COOKIES_PATH)) {
    console.log(`🍪 Loaded cookies.txt`);
  }
});
